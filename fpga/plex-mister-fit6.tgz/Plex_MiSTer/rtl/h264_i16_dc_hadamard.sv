// Intra 16x16 luma DC: inv-quant + Hadamard (ITU 8.5.10).
// Bit-exact to host cavlc::invQuantHadamardDc4x4 / FFmpeg ff_h264_luma_dc_dequant_idct.
// NOT the AC 4x4 path in h264_iq_idct_4x4.sv.
//
// coeff_scan[0:15] = CAVLC zigzag (residualBlock max=16).
// dc_out[ly*4+lx]  = host dcOut[ly][lx] int16.
// Do not sat9 dc_out. Consumer with CBP luma=0: pred += (dc+32)>>6.
//
// Phase 1a MB0 (plex_phase1a_p16skip, qp=25, CBP luma=0):
//   scan = {47, 0x15}
//   dc_out[*] = 2068
//   pred 128 + (2068+32)>>6 = 160
//
// Do not instantiate from Plex.sv / stream_path.

`default_nettype none

module h264_i16_dc_hadamard (
	input  wire signed [15:0] coeff_scan [0:15],
	input  wire [5:0]         qp,
	output reg  signed [15:0] dc_out [0:15]
);
	function automatic [3:0] zz_i;
		input integer i;
		begin
			case (i)
			0: zz_i=4'd0;  1: zz_i=4'd1;  2: zz_i=4'd4;  3: zz_i=4'd8;
			4: zz_i=4'd5;  5: zz_i=4'd2;  6: zz_i=4'd3;  7: zz_i=4'd6;
			8: zz_i=4'd9;  9: zz_i=4'd12; 10: zz_i=4'd13; 11: zz_i=4'd10;
			12: zz_i=4'd7; 13: zz_i=4'd11; 14: zz_i=4'd14; default: zz_i=4'd15;
			endcase
		end
	endfunction

	function automatic [3:0] transpose_z;
		input [3:0] z;
		transpose_z = {z[1:0], z[3:2]}; // (z>>2)|((z<<2)&0xF)
	endfunction

	function automatic integer mf0_of;
		input [5:0] q;
		begin
			case (q % 6)
			0: mf0_of = 10;
			1: mf0_of = 11;
			2: mf0_of = 13;
			3: mf0_of = 14;
			4: mf0_of = 16;
			default: mf0_of = 18;
			endcase
		end
	endfunction

	integer i, t;
	integer z0, z1, z2, z3;
	integer qmul;
	reg signed [15:0] input_t [0:15];
	reg signed [17:0] temp [0:15];
	integer p;

	always @* begin
		for (i = 0; i < 16; i = i + 1)
			input_t[i] = 16'sd0;
		for (i = 0; i < 16; i = i + 1) begin
			t = transpose_z(zz_i(i));
			input_t[t] = coeff_scan[i];
		end

		for (i = 0; i < 4; i = i + 1) begin
			z0 = input_t[4*i+0] + input_t[4*i+1];
			z1 = input_t[4*i+0] - input_t[4*i+1];
			z2 = input_t[4*i+2] - input_t[4*i+3];
			z3 = input_t[4*i+2] + input_t[4*i+3];
			temp[4*i+0] = z0 + z3;
			temp[4*i+1] = z0 - z3;
			temp[4*i+2] = z1 - z2;
			temp[4*i+3] = z1 + z2;
		end

		qmul = (mf0_of(qp) * 16) << ((qp / 6) + 2);

		for (i = 0; i < 4; i = i + 1) begin
			z0 = temp[0+i] + temp[8+i];
			z1 = temp[0+i] - temp[8+i];
			z2 = temp[4+i] - temp[12+i];
			z3 = temp[4+i] + temp[12+i];
			p = ((z0 + z3) * qmul + 128) >>> 8;
			dc_out[i*4+0] = p[15:0];
			p = ((z1 + z2) * qmul + 128) >>> 8;
			dc_out[i*4+1] = p[15:0];
			p = ((z1 - z2) * qmul + 128) >>> 8;
			dc_out[i*4+2] = p[15:0];
			p = ((z0 - z3) * qmul + 128) >>> 8;
			dc_out[i*4+3] = p[15:0];
		end
	end
endmodule

`default_nettype wire
